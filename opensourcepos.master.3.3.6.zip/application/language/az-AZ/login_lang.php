<?php 

$lang["login_gcaptcha"] = "Mən robot deyiləm.";
$lang["login_go"] = "daxil ol";
$lang["login_invalid_gcaptcha"] = "Yanlış, Mən robot deyiləm.";
$lang["login_invalid_installation"] = "Quraşdırma düzgün deyil, php.ini faylını yoxlayın.";
$lang["login_invalid_username_and_password"] = "Ad və ya şifrə səhvdir.";
$lang["login_login"] = "Giriş";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "Şifrə";
$lang["login_username"] = "İstifadəçi";
$lang["login_welcome"] = "";

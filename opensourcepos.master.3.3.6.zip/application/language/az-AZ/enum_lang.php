<?php 

$lang["enum_half_down"] = "Yarım aşağı";
$lang["enum_half_even"] = "Yarım hətta";
$lang["enum_half_five"] = "Yarısı";
$lang["enum_half_odd"] = "Yarım təkliklərdə";
$lang["enum_half_up"] = "Yarım yuxarı";
$lang["enum_round_down"] = "Yuvarla aşağı";
$lang["enum_round_up"] = "Yuvarla yuxarı";

<?php 

$lang["messages_first_name"] = "Nombre(s)";
$lang["messages_last_name"] = "Apellido(s)";
$lang["messages_message"] = "Mensaje";
$lang["messages_message_placeholder"] = "Tu mensaje aquí...";
$lang["messages_message_required"] = "Requiere mensaje";
$lang["messages_multiple_phones"] = "(En caso de varios destinatarios, ingrese los números de teléfono separado por comas)";
$lang["messages_phone"] = "Número de teléfono";
$lang["messages_phone_number_required"] = "Requiere de número telefónico";
$lang["messages_phone_placeholder"] = "Números de teléfonos celulares aquí...";
$lang["messages_sms_send"] = "Enviar SMS";
$lang["messages_successfully_sent"] = "Mensaje enviado exitosamente a: ";
$lang["messages_unsuccessfully_sent"] = "Mensaje no enviado a: ";

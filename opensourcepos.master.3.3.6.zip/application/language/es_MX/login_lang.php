<?php 

$lang["login_gcaptcha"] = "No soy un robot.";
$lang["login_go"] = "Entrar";
$lang["login_invalid_gcaptcha"] = "Por favor compruebe que usted no es un robot.";
$lang["login_invalid_installation"] = "La instalacion no es correcta, revise el archivo php.ini.";
$lang["login_invalid_username_and_password"] = "Usuario y/o Password Invalido.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "Salir";
$lang["login_migration_needed"] = "Una migración de base de datos a %1 empezara después de entrar.";
$lang["login_password"] = "Contraseña";
$lang["login_username"] = "Usuario";
$lang["login_welcome"] = "Bienvenido a %1!";

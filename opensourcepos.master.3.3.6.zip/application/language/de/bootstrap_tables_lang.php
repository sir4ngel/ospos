<?php 

$lang["tables_all"] = "Alle";
$lang["tables_columns"] = "Spalten";
$lang["tables_hide_show_pagination"] = "Seitenzahlen anzeigen/verbergen";
$lang["tables_loading"] = "Lade, bitte warten...";
$lang["tables_page_from_to"] = "Zeige {0} bis {1} von {2} Zeile(n)";
$lang["tables_refresh"] = "Aktualisieren";
$lang["tables_rows_per_page"] = "{0} Einträge pro Seite";
$lang["tables_toggle"] = "Umschalten";

<?php 

$lang["error_no_permission_module"] = "You do not have permission to access the module named";
$lang["error_unknown"] = "Unexpected error";

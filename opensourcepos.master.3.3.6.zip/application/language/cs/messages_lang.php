<?php 

$lang["messages_first_name"] = "Jméno";
$lang["messages_last_name"] = "Příjmení";
$lang["messages_message"] = "Zpráva";
$lang["messages_message_placeholder"] = "Zde napište zprávu...";
$lang["messages_message_required"] = "Zprávu je nutno napsat";
$lang["messages_multiple_phones"] = "(V případě více adresátů oddělujte čísla na mobil čárkami)";
$lang["messages_phone"] = "Telefonní číslo";
$lang["messages_phone_number_required"] = "Telefonní číslo je vyžadováno";
$lang["messages_phone_placeholder"] = "Telefonní číslo...";
$lang["messages_sms_send"] = "Odeslat SMS";
$lang["messages_successfully_sent"] = "Zpráva byla odeslána: ";
$lang["messages_unsuccessfully_sent"] = "Zpráva nebyla odeslána: ";

<?php 

$lang["login_gcaptcha"] = "Nejsem robot.";
$lang["login_go"] = "Přihlásit";
$lang["login_invalid_gcaptcha"] = "Špatné zadání.";
$lang["login_invalid_installation"] = "Instalace není v pořádku, zkontrolujte soubor php.ini.";
$lang["login_invalid_username_and_password"] = "Neplatné jméno nebo heslo.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "Heslo";
$lang["login_username"] = "Uživatelské jméno";
$lang["login_welcome"] = "";

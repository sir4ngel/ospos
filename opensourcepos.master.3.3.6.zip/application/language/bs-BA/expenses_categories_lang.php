<?php 

$lang["category_name_required"] = "Naziv kategorije je obavezan";
$lang["expenses_categories_add_item"] = "Dodaj kategoriju";
$lang["expenses_categories_cannot_be_deleted"] = "Nije moguće izbrisati kategoriju";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Da li ste sigurni da želite da izbrišete izabranu kategoriju?";
$lang["expenses_categories_confirm_restore"] = "Da li ste sigurni da želite da vratite izabranu kategoriju?";
$lang["expenses_categories_description"] = "Opis Kategorije";
$lang["expenses_categories_error_adding_updating"] = "Greška prilikom dodavanja / ažuriranja kategorije";
$lang["expenses_categories_info"] = "Informacije o Kategoriji";
$lang["expenses_categories_name"] = "Naziv Kategorije";
$lang["expenses_categories_new"] = "Nova Kategorija";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Nema kategorije za prikaz";
$lang["expenses_categories_none_selected"] = "Niste odabrali nijednu Kategoriju";
$lang["expenses_categories_one_or_multiple"] = "Kategorija";
$lang["expenses_categories_quantity"] = "Količina";
$lang["expenses_categories_successful_adding"] = "Kategorija je uspješno dodata";
$lang["expenses_categories_successful_deleted"] = "Brisanje kategorije je uspješno";
$lang["expenses_categories_successful_updating"] = "Ažuriranje kategorije je uspješno";
$lang["expenses_categories_update"] = "Ažuriraj kategoriju";

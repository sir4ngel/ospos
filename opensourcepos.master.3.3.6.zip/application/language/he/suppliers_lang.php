<?php 

$lang["suppliers_account_number"] = "מספר חשבון";
$lang["suppliers_agency_name"] = "שם הסוכנות";
$lang["suppliers_cannot_be_deleted"] = "לא ניתן למחוק את הספקים שנבחרו. לאחד או יותר יש מכירות.";
$lang["suppliers_category"] = "קטגוריה";
$lang["suppliers_company_name"] = "שם חברה";
$lang["suppliers_company_name_required"] = "שם חברה הינו שדה חובה.";
$lang["suppliers_confirm_delete"] = "האם אתה בטוח שברצונך למחוק את הספקים שנבחרו?";
$lang["suppliers_confirm_restore"] = "האם אתה בטוח שברצונך לשחזר את הספקים שנבחרו?";
$lang["suppliers_cost"] = "עלות קניה ספק";
$lang["suppliers_error_adding_updating"] = "עדכון הספק או ההוספה נכשלו.";
$lang["suppliers_goods"] = "ספק מוצרים";
$lang["suppliers_new"] = "ספק חדש";
$lang["suppliers_none_selected"] = "לא בחרת ספק(ים) למחיקה.";
$lang["suppliers_one_or_multiple"] = "ספק(ים)";
$lang["suppliers_successful_adding"] = "הוספת בהצלחה את הספק";
$lang["suppliers_successful_deleted"] = "נמחק בהצלחה";
$lang["suppliers_successful_updating"] = "עדכנת בהצלחה את הספק";
$lang["suppliers_supplier"] = "ספק";
$lang["suppliers_supplier_id"] = "מזהה";
$lang["suppliers_tax_id"] = "מזהה מס";
$lang["suppliers_update"] = "עדכון הספק";

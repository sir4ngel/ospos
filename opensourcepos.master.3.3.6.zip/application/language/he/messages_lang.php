<?php 

$lang["messages_first_name"] = "שם פרטי";
$lang["messages_last_name"] = "שם משפחה";
$lang["messages_message"] = "הודעה";
$lang["messages_message_placeholder"] = "ההודעה שלך כאן...";
$lang["messages_message_required"] = "רישום הודעה נדרש";
$lang["messages_multiple_phones"] = "(במקרה של מספר נמענים, הזן מספרי טלפון המופרדים באמצעות פסיקים)";
$lang["messages_phone"] = "מספר טלפון";
$lang["messages_phone_number_required"] = "מספר טלפון נדרש";
$lang["messages_phone_placeholder"] = "מספר נייד כאן ...";
$lang["messages_sms_send"] = "שלח הודעת טקסט";
$lang["messages_successfully_sent"] = "ההודעה נשלחה בהצלחה אל: ";
$lang["messages_unsuccessfully_sent"] = "שגיאה בשליחת הודעה אל: ";

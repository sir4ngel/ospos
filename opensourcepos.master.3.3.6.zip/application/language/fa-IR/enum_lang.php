<?php 

$lang["enum_half_down"] = "نیمه پایین";
$lang["enum_half_even"] = "نیمه حتی";
$lang["enum_half_five"] = "نیمی از پنج";
$lang["enum_half_odd"] = "نیمی عجیب";
$lang["enum_half_up"] = "نیمه بالا";
$lang["enum_round_down"] = "دور پایین";
$lang["enum_round_up"] = "دور بالا";
